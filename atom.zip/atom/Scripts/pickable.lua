-- new script file
function OnAfterSceneLoaded(self)
  self:SetTraceAccuracy(Vision.TRACE_POLYGON)

  --self:GetComponentOfType("vHavokRigidBody"):SetMass(10)
end