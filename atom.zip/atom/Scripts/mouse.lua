

function OnAfterSceneLoaded()
	--self.w, self.h = Screen:GetViewportSize()
end
